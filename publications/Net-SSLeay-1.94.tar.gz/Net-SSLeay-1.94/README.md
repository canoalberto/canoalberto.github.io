[![GitHub Actions build status](https://github.com/radiator-software/p5-net-ssleay/workflows/CI/badge.svg?branch=master)](https://github.com/radiator-software/p5-net-ssleay/actions?query=workflow%3ACI)
[![AppVeyor build status](https://ci.appveyor.com/api/projects/status/ss6vl40o4otdq8ii/branch/master?svg=true)](https://ci.appveyor.com/project/h-vn/p5-net-ssleay/branch/master)

# Net-SSLeay: Perl bindings for OpenSSL and LibreSSL

Information about the latest stable release is available on
[MetaCPAN](https://metacpan.org/release/Net-SSLeay).

See [README](README) for more information about this module.
